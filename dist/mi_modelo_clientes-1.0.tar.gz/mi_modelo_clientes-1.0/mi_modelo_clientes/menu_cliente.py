def menu_cliente(cliente):
    while True:
        print(f"\n--- Menú de {cliente.nombre} ---")
        print("1. Ver perfil")
        print("2. Agregar fondos")
        print("3. Realizar compra")
        print("4. Ver saldo")
        print("5. Cerrar sesión")

        opcion = input("Seleccione una opción: ")
        if opcion == "1":
            print(f"Nombre: {cliente.nombre}")
            print(f"Apellido: {cliente.apellido}")
            print(f"Email: {cliente.email}")
            print(f"Saldo: ${cliente.saldo:.2f}")
        elif opcion == "2":
            monto = float(input("Monto a agregar: "))
            cliente.agregar_fondos(monto)
        elif opcion == "3":
            monto = float(input("Monto de la compra: "))
            cliente.realizar_compra(monto)
        elif opcion == "4":
            print(f"Saldo actual: ${cliente.saldo:.2f}")
        elif opcion == "5":
            print("Sesión cerrada.")
            break
        else:
            print("Opción no válida.")
