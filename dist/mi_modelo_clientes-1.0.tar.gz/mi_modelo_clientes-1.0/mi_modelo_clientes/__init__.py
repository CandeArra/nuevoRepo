# mi_modelo_clientes/__init__.py

from .cliente import Cliente
from .sistema_usuarios import registrar_usuario, login_usuario, mostrar_usuarios
