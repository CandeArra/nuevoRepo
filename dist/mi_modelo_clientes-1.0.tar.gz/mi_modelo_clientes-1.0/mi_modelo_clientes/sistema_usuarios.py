from mi_modelo_clientes.cliente import Cliente
from mi_modelo_clientes.menu_cliente import menu_cliente

usuarios = {}     # usuario -> contraseña
clientes = {}     # usuario -> Cliente

def registrar_usuario():
    while True:
        nombre_usuario = input("Nombre de usuario: ")
        if nombre_usuario in usuarios:
            print("El usuario ya existe.")
            continue

        contraseña = input("Contraseña (mínimo 6 caracteres): ")
        if len(contraseña) < 6:
            print("Contraseña muy corta.")
            continue

        nombre = input("Nombre real: ")
        apellido = input("Apellido: ")
        email = input("Email: ")
        saldo = float(input("Saldo inicial: "))

        cliente = Cliente(nombre, apellido, email, saldo)
        usuarios[nombre_usuario] = contraseña
        clientes[nombre_usuario] = cliente

        print(f"Usuario {nombre_usuario} registrado con éxito.")
        break

def login_usuario():
    nombre_usuario = input("Nombre de usuario: ")
    if nombre_usuario not in usuarios:
        print("El usuario no existe.")
        return

    contraseña = input("Contraseña: ")
    if usuarios[nombre_usuario] == contraseña:
        print(f"Bienvenido {nombre_usuario}!")
        menu_cliente(clientes[nombre_usuario])
    else:
        print("Contraseña incorrecta.")

def mostrar_usuarios():
    if not usuarios:
        print("No hay usuarios registrados.")
    else:
        print("Usuarios registrados:")
        for u in usuarios:
            print(f"- {u}")
 