class Cliente:
    def __init__(self, nombre, apellido, email, saldo=0.0):
        self.nombre = nombre
        self.apellido = apellido
        self.email = email
        self.saldo = saldo

    def __str__(self):
        return f"{self.nombre} {self.apellido}"

    def agregar_fondos(self, monto):
        if monto > 0:
            self.saldo += monto
            print(f"Se agregaron ${monto:.2f} a la cuenta de {self.nombre}.")
        else:
            print("El monto debe ser mayor a cero.")

    def realizar_compra(self, monto):
        if monto <= self.saldo:
            self.saldo -= monto
            print(f"Compra realizada por ${monto:.2f}. Saldo actual: ${self.saldo:.2f}")
        else:
            print("Fondos insuficientes.")